# DigitScope Pro

A self-hostable Deriv synthetic-index analytics and manually confirmed trading terminal.

## Included
- Public Deriv WebSocket tick stream and 1,000-tick rolling digit analysis.
- Digit 0–9 frequencies, Over 4 / Under 5, Even / Odd, recent tick tape.
- OAuth 2.0 Authorization Code + PKCE sign-in.
- Server-side token exchange and server-held OAuth token (never returned to browser JS).
- Account selection and account-specific authenticated WebSocket OTP.
- Manual contract quotes and separately confirmed purchases for demo or real accounts.
- Open-position monitoring, balance updates and manual early sell request.
- Real-account acknowledgement gate; no automatic trading.

## Requirements
- Node.js 20+
- A Deriv OAuth 2.0 app registered at https://developers.deriv.com/
- The app must allow the `trade` scope.
- Redirect URI registered exactly as `http://localhost:3000/auth/callback` for local testing.

## Run locally
```bash
cp .env.example .env
# Edit .env: DERIV_CLIENT_ID, SESSION_SECRET, DERIV_REDIRECT_URI
npm install
npm start
```
Open http://localhost:3000

Generate a session secret:
```bash
node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))"
```

## Deriv setup
1. Sign in at https://developers.deriv.com/ and register an OAuth 2.0 app.
2. Add your callback URL exactly as configured in `DERIV_REDIRECT_URI`.
3. Enable the `trade` scope for the app.
4. Put the app's client ID in `.env`.
5. Use the Connect Deriv button. Deriv handles sign-in and consent. DigitScope never asks for your Deriv password.

The OAuth callback exchanges the one-time authorization code server-side using PKCE. Deriv's current OAuth guide states access tokens expire and no refresh token is issued; users must re-authorize after expiry.

## Deployment checklist
- Deploy behind HTTPS and set `NODE_ENV=production`.
- Register the production HTTPS callback URL in your Deriv OAuth app and set `DERIV_REDIRECT_URI` to the exact same URL.
- Use a long random `SESSION_SECRET` stored in the host's secret manager.
- Replace the default Express MemoryStore with Redis or another production session store before multi-instance/production use.
- Add persistent session encryption/key management, monitoring, backups, rate limits and a privacy policy appropriate to your jurisdiction.
- Consider an explicit account allowlist and trade-size limits before enabling real-account trading.
- Review Deriv's current API terms and product availability for your account and region.

## Safety notes
- This is a starter implementation, not a regulated brokerage or investment service.
- Statistical frequencies are historical descriptions, not reliable predictions or a demonstrated trading edge.
- Trades can lose the entire stake. Demo-test first.
- No automated trading strategy is enabled. Every trade requires a new quote and explicit Buy confirmation.
- The app does not store passwords, payment credentials or API tokens in localStorage.
- The real-account checkbox is an additional user-intent gate, not a guarantee against loss.

## API integration references
- API overview: https://developers.deriv.com/docs/intro/api-overview/
- OAuth + PKCE: https://developers.deriv.com/docs/intro/oauth/
- Tick history: https://developers.deriv.me/docs/data/ticks-history/
- Proposals: https://developers.deriv.me/docs/trading/proposal/
- Trading operations: https://developers.deriv.com/docs/trading/
