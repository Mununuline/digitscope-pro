import express from "express";
import session from "express-session";
import helmet from "helmet";
import compression from "compression";
import rateLimit from "express-rate-limit";
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const CLIENT_ID = process.env.DERIV_CLIENT_ID;
const REDIRECT_URI = process.env.DERIV_REDIRECT_URI || `http://localhost:${PORT}/auth/callback`;
const SESSION_SECRET = process.env.SESSION_SECRET;

if (!CLIENT_ID || !SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.error("Missing DERIV_CLIENT_ID or SESSION_SECRET (minimum 32 characters). Copy .env.example to .env and configure it.");
  process.exit(1);
}
if (process.env.NODE_ENV === "production") app.set("trust proxy", 1);

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: {
  directives: {
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'"],
    styleSrc: ["'self'", "'unsafe-inline'"],
    connectSrc: ["'self'", "wss://api.derivws.com", "https://api.derivws.com", "https://auth.deriv.com"],
    imgSrc: ["'self'", "data:"],
    objectSrc: ["'none'"], frameAncestors: ["'none'"]
  }
}}));
app.use(compression());
app.use(express.json({ limit: "30kb" }));
app.use(session({
  name: "digitscope.sid",
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 8 *  60 * 60 * 1000
  }
  // IMPORTANT: MemoryStore is for local development only. Use Redis in production.
}));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 90, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(__dirname, "public"), { etag: true, maxAge: "1h" }));

const random = (n=32) => crypto.randomBytes(n).toString("base64url");
const sha256 = s => crypto.createHash("sha256").update(s).digest("base64url");
const apiFetch = async (url, options={}) => {
  const response = await fetch(url, { ...options, headers: { "Content-Type":"application/json", ...(options.headers||{}) }});
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data?.error?.message || data?.message || `Deriv API returned ${response.status}`);
  return data;
};
const requireAuth = (req,res,next) => {
  if (!req.session.deriv?.accessToken) return res.status(401).json({error:"Connect your Deriv account first."});
  if (Date.now() > req.session.deriv.expiresAt) {
    req.session.destroy(()=>{});
    return res.status(401).json({error:"Your Deriv session expired. Please sign in again."});
  }
  next();
};
const sameOrigin = (req,res,next) => {
  const origin = req.get("origin");
  if (origin) {
    try {
      const expected = new URL(REDIRECT_URI).origin;
      if (origin !== expected) return res.status(403).json({error:"Cross-origin request blocked."});
    } catch {}
  }
  next();
};
app.use("/api", sameOrigin);

app.get("/api/config", (req,res) => res.json({
  configured: Boolean(CLIENT_ID),
  connected: Boolean(req.session.deriv?.accessToken && Date.now() < req.session.deriv.expiresAt),
  redirectUri: REDIRECT_URI
}));

app.get("/auth/login", (req,res) => {
  const verifier = random(48);
  const state = random(24);
  req.session.oauth = { verifier, state, createdAt: Date.now() };
  const u = new URL("https://auth.deriv.com/oauth2/auth");
  u.search = new URLSearchParams({
    response_type: "code",
    client_id: CLIENT_ID,
    redirect_uri: REDIRECT_URI,
    scope: "trade",
    state,
    code_challenge: sha256(verifier),
    code_challenge_method: "S256"
  }).toString();
  res.redirect(u.toString());
});

app.get("/auth/callback", async (req,res) => {
  const saved = req.session.oauth;
  const { code, state, error } = req.query;
  delete req.session.oauth;
  if (error) return res.redirect("/?auth_error=" + encodeURIComponent(String(error)));
  if (!saved || !code || !state || state !== saved.state || Date.now()-saved.createdAt > 10*60*1000) {
    return res.status(400).send("OAuth state check failed. Close this tab and try again.");
  }
  try {
    const body = new URLSearchParams({
      grant_type: "authorization_code",
      client_id: CLIENT_ID,
      code: String(code),
      code_verifier: saved.verifier,
      redirect_uri: REDIRECT_URI
    });
    const tokenResponse = await fetch("https://auth.deriv.com/oauth2/token", {
      method:"POST", headers:{"Content-Type":"application/x-www-form-urlencoded"}, body
    });
    const tokenData = await tokenResponse.json();
    if (!tokenResponse.ok || !tokenData.access_token) throw new Error(tokenData.error_description || tokenData.error || "Token exchange failed");
    req.session.deriv = {
      accessToken: tokenData.access_token,
      expiresAt: Date.now() + Number(tokenData.expires_in || 3600)*1000,
      connectedAt: Date.now()
    };
    res.redirect("/?connected=1");
  } catch (e) {
    console.error("OAuth callback error:", e.message);
    res.redirect("/?auth_error=" + encodeURIComponent("Deriv authorization failed. Check your app settings and try again."));
  }
});

app.get("/api/accounts", requireAuth, async (req,res) => {
  try {
    const data = await apiFetch("https://api.derivws.com/trading/v1/options/accounts", {
      headers:{Authorization:`Bearer ${req.session.deriv.accessToken}`}
    });
    const raw = data.accounts || data.data || [];
    const accounts = raw.map(a=>({
      account_id: a.account_id || a.id,
      account_type: a.account_type || a.landing_company_name || (String(a.account_id||"").startsWith("VRTC")?"demo":"real"),
      currency: a.currency || "USD",
      display_name: a.display_name || a.account_name || a.account_id
    })).filter(a=>a.account_id);
    res.json({accounts});
  } catch(e) { res.status(502).json({error:e.message}); }
});

app.post("/api/otp", requireAuth, async (req,res) => {
  const accountId = String(req.body?.accountId || "");
  const accountType = String(req.body?.accountType || "");
  if (!/^[A-Za-z0-9_-]{3,40}$/.test(accountId)) return res.status(400).json({error:"Invalid account selection."});
  if (!["demo","real"].includes(accountType)) return res.status(400).json({error:"Invalid account type."});
  if (accountType === "real" && req.body?.realAcknowledged !== true) return res.status(403).json({error:"Real-account acknowledgement is required."});
  try {
    const data = await apiFetch(`https://api.derivws.com/trading/v1/options/accounts/${encodeURIComponent(accountId)}/otp`, {
      method:"POST", headers:{Authorization:`Bearer ${req.session.deriv.accessToken}`}, body:"{}"
    });
    const wsUrl = data?.data?.url || data?.url || data?.data?.websocket_url;
    if (!wsUrl || !String(wsUrl).startsWith("wss://api.derivws.com/")) throw new Error("Deriv did not return a valid authenticated WebSocket URL.");
    res.json({url:wsUrl, accountType});
  } catch(e) { res.status(502).json({error:e.message}); }
});

app.post("/auth/logout", (req,res) => {
  req.session.destroy(()=>res.json({ok:true}));
});

app.get("*", (req,res) => res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT, () => console.log(`DigitScope Pro running at http://localhost:${PORT}`));
